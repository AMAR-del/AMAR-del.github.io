package com.gsnotes.services;

import com.gsnotes.bo.Element;
import com.gsnotes.bo.Filiere;
import com.gsnotes.bo.Niveau;
import com.gsnotes.bo.Module;
import org.springframework.web.multipart.MultipartFile;

import java.util.List;

public interface IntNoteDeliberationService {
    public void EnregistrerExel(MultipartFile file);
    public void GererExel(String filename);
}
