package com.gsnotes.services.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.gsnotes.bo.Utilisateur;
import com.gsnotes.dao.IntUtilisateurDao;
import com.gsnotes.dao.IntUtilisateurDao;
import com.gsnotes.services.IPersonService;
import com.gsnotes.utils.ExcelExporter;

@Service
@Transactional
public class PersonServiceImpl implements IPersonService {

	@Autowired
	private IntUtilisateurDao personDao;

	public List<Utilisateur> getAllPersons() {

		return personDao.findAll();
	}

	public void deletePerson(Long id) {
		personDao.deleteById(id);

	}

	public Utilisateur getPersonById(Long id) {
		return personDao.getById(id);

	}

	public void addPerson(Utilisateur pPerson) {
		personDao.save(pPerson);

	}

	public void updatePerson(Utilisateur pPerson) {
		personDao.save(pPerson);

	}

	public ExcelExporter preparePersonExport(List<Utilisateur> persons) {
		String[] biencolumnNames = new String[] { "Nom", "Prénom", "CIN", "Email", "Télé" };
		String[][] info = new String[persons.size()][5];

		int i = 0;
		for (Utilisateur u : persons) {
			info[i][0] = u.getNom();
			info[i][1] = u.getPrenom();
			info[i][2] = u.getCin();
			info[i][3] = u.getEmail();
			info[i][4] = u.getTelephone();
			i++;
		}

		return new ExcelExporter(biencolumnNames, info, "persons");

	}

	public Utilisateur getPersonByCin(String cin) {

		return personDao.getUserByCin( cin);

	}

}
