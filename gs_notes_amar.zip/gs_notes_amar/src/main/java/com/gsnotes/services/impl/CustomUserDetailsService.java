package com.gsnotes.services.impl;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import com.gsnotes.bo.Compte;
import com.gsnotes.bo.UserPrincipal;
import com.gsnotes.dao.IntCompteDao;
import com.gsnotes.services.ICompteService;


@Service
public class CustomUserDetailsService implements UserDetailsService {

	@Autowired
	private ICompteService userRepository; 

	Logger LOGGER = LoggerFactory.getLogger(getClass());

	public CustomUserDetailsService() {
	}

	@Override
	public UserDetails loadUserByUsername(String username) {

		Compte user = null;

		user = userRepository.getAccountByUserName(username);

		if (user == null) {

			LOGGER.warn("Utilisateur " + username + " introuvable ");

			throw new UsernameNotFoundException(username);
		}

		if (user.getRole() == null) {
			String msg = "Utilisateur " + username + " n'ayant aucune autorisation ";

			LOGGER.warn(msg);

			throw new UsernameNotFoundException(msg);
		}


		return new UserPrincipal(user);
	}

}