package com.gsnotes.services.impl;

import java.util.List;

import org.passay.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.gsnotes.bo.Compte;
import com.gsnotes.bo.Role;
import com.gsnotes.bo.Utilisateur;
import com.gsnotes.dao.IntCompteDao;
import com.gsnotes.dao.IntRoleDao;
import com.gsnotes.dao.IntUtilisateurDao;
import com.gsnotes.services.ICompteService;
import com.gsnotes.utils.ExcelExporter;

@Service
@Transactional
public class CompteServiceImpl implements ICompteService {
	@Autowired
	private IntCompteDao u;

	@Autowired
	private IntRoleDao r;

	@Autowired
	private IntUtilisateurDao p;

	@Autowired
	private PasswordEncoder pe;
	@Override
	public Compte getAccountByUserName(String login) {
	

		return u.getCompteByUsername(login);
	}

	public List<Role> getAllRoles() {
		return r.findAll();
	}

	public List<Compte> getAllAccounts() {
		return u.findAll();
	}

	public String generatePassayPassword() {
		CharacterRule digits = new CharacterRule(EnglishCharacterData.Digit);

		PasswordGenerator passwordGenerator = new PasswordGenerator();
		String password = passwordGenerator.generatePassword(10, digits);

		return password;
	}
	public ExcelExporter prepareCompteExport(List<Compte> comptes) {
		String[] columnNames = new String[] { "Login", "Rôle", "Nom & Prénom" };
		String[][] info = new String[comptes.size()][3];

		int i = 0;
		for (Compte u : comptes) {
			info[i][0] = u.getLogin();
			info[i][1] = u.getRole().getNomRole();
			info[i][2] = u.getProprietaire().getNom() + " " + u.getProprietaire().getPrenom();
			i++;
		}

		return new ExcelExporter(columnNames, info, "comptes");

	}

	public String createUser(Long idRole, Long idPerson) {

		Utilisateur person = p.getById(idPerson);

		Compte userAccount = new Compte();

		userAccount.setProprietaire(person);

		userAccount.setRole(r.getById(idRole));

		String generatedPass = generatePassayPassword();

		String encodedPass = pe.encode(generatedPass);

		userAccount.setPassword(encodedPass);

		String login = person.getNom() + person.getPrenom();

		Compte account = u.getCompteByUsername(login);

		if (account == null) {

			userAccount.setLogin(login);
			u.save(userAccount);
			return generatedPass;
		}

		int i = 0;
		while (true) {

			login = person.getNom() + person.getPrenom() + "_" + i;
			account = u.getCompteByUsername(login);
			if (account == null) {
				userAccount.setLogin(login);
				u.save(userAccount);
				return generatedPass;
			}

			i++;
		}
	}


}
