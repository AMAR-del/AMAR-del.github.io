package com.gsnotes.services.impl;
import javax.servlet.ServletContext;
import com.gsnotes.bo.*;
import com.gsnotes.bo.Module;
import com.gsnotes.dao.*;
import com.gsnotes.services.IntNoteDeliberationService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.util.*;

@Service
public abstract class NoteDeDeliberationServiceImpl implements IntNoteDeliberationService {
    private final Path root = Paths.get("uploads");

    @Autowired
    private IntModuleDao m;
    @Autowired
    private IntNiveauDao n;
    @Autowired
    private IntElementDao e;
    @Autowired
    private IntFiliereDao f;
    @Autowired
    private IntInscriptionAnnuelleDao i;
    @Autowired
    private IntInscriptionModuleDao in;
    @Autowired
    private IntInscriptionMatiereDao inm;
    @Autowired
    private IntEtudiantDao et;
    @Autowired
    ServletContext cnt; 

 
    public void Enregister(MultipartFile file) {
        try {
            Files.copy(file.getInputStream(), Paths.get(cnt.getRealPath("telecharger") + file.getOriginalFilename()), StandardCopyOption.REPLACE_EXISTING);
        } catch (Exception e) {
            throw new RuntimeException(" Erreur: " + e.getMessage());
        }
    }

}

