package com.gsnotes.web.controllers;

import com.gsnotes.services.IntNoteDeliberationService;
import com.gsnotes.services.IntNoteDeliberationService;

import javax.servlet.ServletContext;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.nio.file.Paths;

@Controller
@RequestMapping("/enseg")
public class NoteDeDeliberation {

    @Autowired
    IntNoteDeliberationService noteDelibService;
    
    @Autowired
    ServletContext context;

    @GetMapping("/noteDelibeartion")
    public String noteDelib() {
        return "/enseg/noteDeliberation";
    }

    @PostMapping("/telecharger")
    public String Telecharger(@RequestParam("fichier") MultipartFile file, Model model) {
    	
        String path = Paths.get(context.getRealPath("uploads") + file.getOriginalFilename()).toString();
        noteDelibService.EnregistrerExel(file);
        System.out.println(path);
        noteDelibService.GererExel(path);
        model.addAttribute("m", file.getOriginalFilename() + "tres bien opperation effectuer");
        model.addAttribute("s", "bien");
        return "/enseg/noteDeliberation";
    }

}
