package com.gsnotes.dao;

import com.gsnotes.bo.InscriptionMatiere;
import org.springframework.data.jpa.repository.JpaRepository;

public interface IntInscriptionMatiereDao extends JpaRepository<InscriptionMatiere, Long> {
}
