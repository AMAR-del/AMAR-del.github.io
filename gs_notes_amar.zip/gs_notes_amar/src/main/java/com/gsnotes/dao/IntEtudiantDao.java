package com.gsnotes.dao;

import com.gsnotes.bo.Etudiant;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

public interface IntEtudiantDao extends JpaRepository<Etudiant, Long> {
    public Etudiant getByCne(String cne);
}
