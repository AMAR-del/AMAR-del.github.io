package com.gsnotes.dao;

import com.gsnotes.bo.Filiere;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

public interface IntFiliereDao extends JpaRepository<Filiere, Long> {
}
