package com.gsnotes.dao;

import com.gsnotes.bo.Element;
import com.gsnotes.bo.Filiere;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

public interface IntElementDao extends JpaRepository<Element, Long> {
    public Element getByTitle(String title);
}
