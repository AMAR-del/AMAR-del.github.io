package com.gsnotes.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.gsnotes.bo.Utilisateur;

public interface IntUtilisateurDao extends JpaRepository<Utilisateur, Long> {

	public Utilisateur getUserByCin(String cin);

}
