package com.gsnotes.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.gsnotes.bo.Compte;

public interface IntCompteDao extends JpaRepository<Compte, Long> {
	public Compte getCompteByUsername(String username);

}
