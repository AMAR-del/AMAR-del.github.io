package com.gsnotes.dao;

import com.gsnotes.bo.InscriptionModule;
import org.springframework.data.jpa.repository.JpaRepository;

public interface IntInscriptionModuleDao extends JpaRepository<InscriptionModule, Long> {
}
